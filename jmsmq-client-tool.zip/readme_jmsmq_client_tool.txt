https://github.com/kishorrekonda/LDAPAuthenticator/wiki/JMS-connectivity-tester-to-IBM-MQ

What does this this tool offer?
    It works like any typical java based JMS client built using MQ classes for JMS.
    Helps validating connection to IBM MQ with configuration in hand.
    Allows to test production and consumption of messages to/from MQ queue.

Prerequisite 
Ensure you have access to list of mq client jars from B2Bi install under <b2b_install_home>/jar/mqseries/x_x_x_x folder com.ibm.mqjms.jar
com.ibm.mq.headers.jar
com.ibm.mq.jar
com.ibm.mq.jmqi.jar
jms.jar

Usage
    Extract jms.custom.connector.jar and jms-inputs.properties from jmsmq-client-tool.zip into a temporary folder on B2Bi host. Note this folder need not be under <b2b_install_home> location.
    copy jars from prerequisite section over to that same temporary folder.
    replace sample values in jms-inputs.properties with needed settings that were received from MQ server admin.

jdk/bin/java -classpath jms.custom.connector.jar:com.ibm.mqjms.jar JMSTester4MQ [path-to-input-file]

Note - If you are using this tool for B2Bi product, prefer to use jdk under <b2b_install_home>
e.g., <b2b_install_home>/jdk/bin/java -cp jms.custom.connector.jar:<b2b_install_home>/jar/mqseries/9_2_0_7/com.ibm.mqjms.jar JMSTester4MQ [path-to-input-file]

